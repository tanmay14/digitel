package org.tmf.openapi.servicecatalog;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ServiceCatalogServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(ServiceCatalogServiceApplication.class, args);
	}
}
