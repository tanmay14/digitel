package org.tmf.openapi.servicecatalog.service;

import static org.tmf.openapi.catalog.common.ListUtils.toList;

import java.util.List;
import java.util.Optional;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.tmf.openapi.catalog.domain.catalog.Category;
import org.tmf.openapi.catalog.repository.CategoryRepository;

import com.querydsl.core.types.Predicate;

@Service
public class CategoryService {

	@Autowired
	private CategoryRepository categoryRepository;

	public ServiceCategory createCategory(@Valid ServiceCategory category) {

		if (category.getId() != null) {
			throw new IllegalArgumentException("id must be empty while creating Category");
		}

		setDefaultValues(category);

		return categoryRepository.save(category);
	}

	public ServiceCategory findCategory(@NotNull String id) {
		return categoryRepository.findById(id).get();
	}

	public List<ServiceCategory> findAllCategories(Predicate predicate) {

		if (null == predicate) {
			return categoryRepository.findAll();
		}
		return toList(categoryRepository.findAll(predicate));
	}

	public void deleteCategory(@NotNull String id) {
		ServiceCategory existingCategory = getExistingCategory(id);
		categoryRepository.delete(existingCategory);

	}

	public ServiceCategory updateCategory(@Valid ServiceCategory category) {

		return categoryRepository.save(category);
	}

	public ServiceCategory partialUpdateCategory(ServiceCategory category) {

		if (null == category.getId()) {
			throw new IllegalArgumentException("id is mandatory field for update.");
		}

		ServiceCategory existingCategory = getExistingCategory(category.getId());

		if (null != category.getName()) {
			existingCategory.setName(category.getName());
		}

		if (null != category.getDescription()) {
			existingCategory.setDescription(category.getDescription());
		}

		if (null != category.getSchemaLocation()) {
			existingCategory.setSchemaLocation(category.getSchemaLocation());
		}

		if (null != category.getVersion()) {
			existingCategory.setVersion(category.getVersion());
		}

		if (null != category.getValidFor()) {
			existingCategory.setValidFor(category.getValidFor());
		}

		if (null != category.getLifecycleStatus()) {
			existingCategory.setLifecycleStatus(category.getLifecycleStatus());
		}

		if (null != category.getParentId()) {
			existingCategory.setParentId(category.getParentId());
		}

		if (null != category.getSubCategory()) {
			existingCategory.setSubCategory(category.getSubCategory());
		}

		if (null != category.getProductOffering()) {
			existingCategory.setProductOffering(category.getProductOffering());
		}

		return saveCategory(existingCategory);

	}

	private ServiceCategory saveCategory(@Valid ServiceCategory category) {
		return categoryRepository.save(category);
	}

	private void setDefaultValues(ServiceCategory category) {
		if (null == category.getType() || category.getType().trim().equals("")) {
			category.setType("Category");
		}

		if (null == category.getVersion()) {
			category.setVersion("1.0");
		}

		if (null == category.getIsRoot()) {
			category.setIsRoot(true);
		}
	}

	private ServiceCategory getExistingCategory(@NotNull String id) {
		Optional<ServiceCategory> existingCategoryOption = categoryRepository.findById(id);
		if (!existingCategoryOption.isPresent()) {
			throw new IllegalArgumentException("Category with id " + id + " doesnot exists");
		}

		ServiceCategory existingCategory = existingCategoryOption.get();
		return existingCategory;
	}

}
