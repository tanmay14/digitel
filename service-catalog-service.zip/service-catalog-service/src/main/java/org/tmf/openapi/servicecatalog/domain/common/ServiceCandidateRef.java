package org.tmf.openapi.servicecatalog.domain.common;

public class ServiceCandidateRef extends BaseRef{

}
